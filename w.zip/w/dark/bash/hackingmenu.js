const hackingmenu = (prefix) => { 
	return `
╭──「 *HACKING TOOLS* 」
┴
✧ ⃟ ⃟ ⃟━━─♡๑୨⊰𝐇𝐚𝐫𝐠𝐚𝐢 𝐏𝐞𝐧𝐜𝐢𝐩𝐭𝐚 𝐁𝐎𝐓, 𝐁𝐚𝐧𝐭𝐮 𝐊𝐚𝐬𝐢𝐡 𝐉𝐞𝐝𝐚 𝐁𝐨𝐭 𝐒𝐞𝐥𝐚𝐦𝐚 5 𝐃𝐞𝐭𝐢𝐤, 𝐅𝐮𝐧𝐠𝐬𝐢 𝐀𝐠𝐚𝐫 𝐌𝐞𝐧𝐜𝐞𝐠𝐚𝐡 𝐓𝐞𝐫𝐣𝐚𝐝𝐢𝐧𝐲𝐚 𝐏𝐞𝐦𝐛𝐥𝐨𝐤𝐢𝐫𝐚𝐧⊱୧๑♡─━ ⃟ ⃟ ⃟ ✧*

𝚏𝚒𝚝𝚞𝚛 𝚑𝚊𝚌𝚔 𝚒𝚗𝚒
𝚍𝚒 𝚜𝚞𝚜𝚞𝚗 𝚘𝚕𝚎𝚑
╭━ 𝙰𝚛𝚒𝚏𝚒 𝚁𝚊𝚣𝚣𝚊𝚚 𝙾𝙵𝙵𝙸𝙲𝙸𝙰𝙻
│
┞𝚓𝚊𝚗𝚐𝚊𝚗 𝚕𝚞𝚙𝚊 𝚜𝚞𝚋𝚜𝚌𝚛𝚒𝚋𝚎
┞𝙲𝚑𝚊𝚗𝚗𝚎𝚕 𝚈𝚘𝚞𝚝𝚞𝚋𝚎𝚗𝚢𝚊
┞𝚂𝚎𝚋𝚊𝚐𝚊𝚒 𝚄𝚌𝚊𝚙𝚊𝚗 𝚃𝚎𝚛𝚒𝚖𝚊 𝚔𝚊𝚜𝚒𝚑
│
╰━ 𝙴𝚛𝚎𝚗 𝚈𝚎𝚊𝚐𝚎𝚛 𝙱𝙾𝚃 

❖ ${prefix}darkfb 🆕
❖ ${prefix}hackfb 🆕
❖ ${prefix}bruteforcefb 🆕
❖ ${prefix}terkeytermux 🆕

`
}
exports.hackingmenu = hackingmenu
