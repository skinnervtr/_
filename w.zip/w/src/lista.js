const lista = () => { 
	return `
	#RenegadosDeKonohaRDK

Líderes:

➥ Sr Hashirama: https://www.youtube.com/channel/UC3diVS4vHWU51G3hnRfHSuw

➥ Sr Tobirama: https://www.youtube.com/channel/UC7PckrMtKscLQifW5LPJe1Q
_____________________________________

VIce Lider:

➥Mr Kakashi:
https://youtube.com/channel/UCgKWlShQzIjzDe7_d2Zbkfw

_____________________________________

Membros:

➥ Sr Itachi: https://youtube.com/c/SrItachiTotoso

➥ Tioh Shikadai: https://www.youtube.com/channel/UCioNBTQGz_4_f2whdyzdnVQ

➥ Tioh Sasukezin: https://youtube.com/channel/UCG9P0H-ImoppaRNymkgBaVg

➥ Sr Gaara: https://www.youtube.com/channel/UCkqMUFLW9ik_mBZbmGjSY3Q

➥ Titia Sarada: https://www.youtube.com/channel/UCJw-ZkkNprLhzzoaeOmp_iQ

➥ Sr Kakuzu: https://www.youtube.com/channel/UCHF6sH0Lwl_4UgEc7AsjZnA

➥ Sr Naruto: https://m.youtube.com/channel/UClrc-FuompLK5gnHHvCPZ-w

➥ Sr Escanor: https://www.youtube.com/channel/UCpO8WJ_1Y3pDywU0u1l3FzQ

➥ Tio Minato: https://www.youtube.com/channel/UCxqpSvAu1-uulKdL_g-EvWg

➥ Sr Deidara: https://www.youtube.com/channel/UCqhDGeOeIGmYjYgRYjmlmDg

➥ Tio Otaku: https://www.youtube.com/c/TioOtaku

➥ Sr Boruto: https://youtube.com/channel/UCei62uJsEWs77QcvyVaH9fQ

➥ Mr Mitsuki: https://www.youtube.com/channel/UCNTLwL8Q-Ea068FUJtQNfaw

➥ Saskezando 2.0: https://youtube.com/channel/UCDIWfVbw8BeneB0M6bxzB3A

➥ Tioh Gaara: https://youtube.com/channel/UCZVLvwT5rTGLiWQCXnmnjsw

➥ Tioh Boruto: https://youtube.com/channel/UCu8w9OPx4ZZgii-ZAlPPtlQ

➥ Mr Neji: https://youtube.com/channel/UCbvRDGdHmOFy0sjo-QF_C_g

➥ Sr Naruto: https://youtube.com/channel/UCyG2WfJcTtUMnOMDu3bBUXw

➥Tio Light: https://youtube.com/c/TioLight%E3%83%84

➥ Sr Zabuza: https://youtube.com/channel/UCpRRxjuVovPlLaiVV20v00Q

➥ Tioh Sasuke:
https://youtube.com/c/TiohSasukeGostoso

➥ Sra Tsunade:
https://youtube.com/channel/UCUVsO7Fh1JTBRncAigdY14A

➥Tia Sarada:
https://youtube.com/channel/UCgM2C_i3yu3VGWovwQNVsnw
`
}
exports.lista = lista